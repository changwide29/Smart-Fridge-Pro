# 🧊 Smart Fridge Pro (ระบบจัดการตู้เย็นอัจฉริยะ)

โปรเจกต์เว็บแอปพลิเคชันสำหรับจัดการวัตถุดิบและอาหารภายในตู้เย็น พัฒนาขึ้นโดยใช้หลักการเขียนโปรแกรมเชิงวัตถุ (Object-Oriented Programming - OOP) ในภาษา PHP เพื่อช่วยลดปัญหาขยะอาหาร (Food Waste) และแจ้งเตือนวันหมดอายุของวัตถุดิบ

## ✨ ฟีเจอร์หลัก (Features)
- **ระบบ Dashboard:** แสดงสถิติภาพรวม จำนวนอาหารที่สดใหม่, ใกล้หมดอายุ, และกราฟสรุปหมวดหมู่อาหาร
- **การจัดการข้อมูล (CRUD):** เพิ่ม, อ่าน, แก้ไข, และลบรายการอาหาร
- **ระบบแจ้งเตือนวันหมดอายุ:** คำนวณวันหมดอายุอัตโนมัติ พร้อมแสดงป้ายสีแจ้งเตือน (เขียว, เหลือง, แดง)
- **ค้นหาและคัดกรอง (Search & Filter):** ค้นหาชื่ออาหารแบบ Real-time ด้วย JavaScript
- **ระบบหมวดหมู่และประเภท:** แบ่งแยกของสด (Perishable) และของแช่แข็ง (Frozen) อย่างชัดเจน

## 🛠️ เทคโนโลยีที่ใช้ (Tech Stack)
- **Backend:** PHP 8.x (โครงสร้างแบบ OOP)
- **Database:** MySQL (เชื่อมต่อผ่าน PDO เพื่อความปลอดภัยจาก SQL Injection)
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Library:** Chart.js (สำหรับวาดกราฟ Donut Chart)

## 📁 โครงสร้างคลาส (OOP Structure)
ระบบถูกออกแบบด้วยหลักการ Inheritance และ Encapsulation:
1. `FoodItem` (Base Class): เก็บคุณสมบัติพื้นฐาน (ชื่อ, ปริมาณ, หน่วยนับ)
2. `PerishableFood` (Sub-Class): สืบทอดจาก FoodItem เพิ่มคุณสมบัติ `expiry_date`
3. `FrozenFood` (Sub-Class): สืบทอดจาก FoodItem เพิ่มคุณสมบัติ `temperature_required`
4. `SmartFridge` (Manager Class): จัดการการเชื่อมต่อฐานข้อมูลและการทำ CRUD Operations

## 👥 สมาชิกผู้จัดทำและการแบ่งงาน
โปรเจกต์นี้เป็นการทำงานร่วมกัน โดยแบ่งสัดส่วนความรับผิดชอบดังนี้:

**1. ภูเขา - Lead Developer & Backend**
- ออกแบบโครงสร้างฐานข้อมูล MySQL (`food_items` table)
- เขียนคลาส OOP ทั้งหมด (`FoodItem.php`, `PerishableFood.php`, `FrozenFood.php`, `SmartFridge.php`)
- จัดการระบบ CRUD Operations ผ่าน PHP Data Objects (PDO)
- เขียนฟังก์ชันคำนวณวันหมดอายุและประมวลผลข้อมูลสถิติ (Data Processing)

**2. ช้าง - Frontend & UI/UX Designer**
- ออกแบบส่วนติดต่อผู้ใช้ (User Interface) ให้รองรับการใช้งานที่ง่ายและสะอาดตา
- เขียน JavaScript สำหรับระบบค้นหา (Real-time Search) และจัดการ Modal (Add/Edit)
- ติดตั้งและตั้งค่า Chart.js สำหรับทำ Dashboard กราฟโดนัท
- จัดทำเอกสารคู่มือ (README) และสไลด์นำเสนอ