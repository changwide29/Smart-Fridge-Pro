// assets/js/script.js

document.addEventListener('DOMContentLoaded', function() {
    // ฟังก์ชันตัวอย่างสำหรับการแจ้งเตือนเมื่ออาหารใกล้หมดอายุด้วย SweetAlert2
    function showExpiryAlert(itemName, daysLeft) {
        if (daysLeft <= 3 && daysLeft > 0) {
            Swal.fire({
                title: 'แจ้งเตือนวันหมดอายุ!',
                text: `${itemName} กำลังจะหมดอายุในอีก ${daysLeft} วัน`,
                icon: 'warning',
                confirmButtonColor: '#f59e0b',
                confirmButtonText: 'รับทราบ'
            });
        } else if (daysLeft <= 0) {
            Swal.fire({
                title: 'สินค้าหมดอายุ!',
                text: `${itemName} หมดอายุแล้ว กรุณานำออกจากตู้เย็น`,
                icon: 'error',
                confirmButtonColor: '#ef4444',
                confirmButtonText: 'จัดการทิ้ง'
            });
        }
    }

    // ตัวอย่างการเตรียม Fetch API เพื่อส่งข้อมูลไปยัง action_handler.php โดยไม่ต้องรีเฟรชหน้า
    // ฟังก์ชันนี้สามารถนำไปผูกกับปุ่ม "เพิ่มอาหาร" หรือ "ลบอาหาร" ได้
    async function manageFoodItem(action, data) {
        try {
            const response = await fetch(`includes/action_handler.php?action=${action}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            
            if(result.success) {
                // ทำการอัปเดต UI หรือโหลดรายการใหม่
                console.log("บันทึกสำเร็จ");
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }
});