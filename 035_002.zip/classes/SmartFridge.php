<?php
// classes/SmartFridge.php

class SmartFridge {
    private $db;

    public function __construct($pdo) {
        $this->db = $pdo;
    }

    // 1. เพิ่มอาหาร (อัปเดตให้รองรับ หมวดหมู่ - category)
    public function addFoodToDB($name, $type, $category, $quantity, $unit, $expiry_date = null, $temperature = null) {
        $sql = "INSERT INTO food_items (name, type, category, quantity, unit, expiry_date, temperature_required) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$name, $type, $category, $quantity, $unit, $expiry_date, $temperature]);
    }

    // 2. แก้ไขอาหาร (ฟังก์ชันใหม่สำหรับระบบ Edit)
    public function updateFoodInDB($id, $name, $type, $category, $quantity, $unit, $expiry_date = null, $temperature = null) {
        $sql = "UPDATE food_items 
                SET name = ?, type = ?, category = ?, quantity = ?, unit = ?, expiry_date = ?, temperature_required = ? 
                WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$name, $type, $category, $quantity, $unit, $expiry_date, $temperature, $id]);
    }

    // 3. ลบอาหาร 
    public function removeFood($id) {
        $stmt = $this->db->prepare("DELETE FROM food_items WHERE id = ?");
        return $stmt->execute([$id]);
    }

    // 4. ดึงรายการอาหารทั้งหมด
    public function getAllFoodItems() {
        $stmt = $this->db->prepare("SELECT * FROM food_items ORDER BY expiry_date ASC, added_date DESC");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // 5. ดึงสถิติสำหรับทำ Dashboard (ฟังก์ชันใหม่)
    public function getDashboardStats() {
        $items = $this->getAllFoodItems();
        $stats = [
            'total' => count($items),
            'expired' => 0,
            'expiring_soon' => 0,
            'fresh' => 0,
            'categories' => [] // สำหรับทำกราฟโดนัท
        ];

        $today = new DateTime();
        $today->setTime(0,0,0);

        foreach ($items as $item) {
            // นับสถิติวันหมดอายุ
            if ($item['expiry_date']) {
                $exp = new DateTime($item['expiry_date']);
                $exp->setTime(0,0,0);
                $daysLeft = (int)$today->diff($exp)->format('%r%a');

                if ($daysLeft < 0) $stats['expired']++;
                elseif ($daysLeft <= 3) $stats['expiring_soon']++;
                else $stats['fresh']++;
            } else {
                $stats['fresh']++; // ไม่มีวันหมดอายุถือว่ายังสด
            }

            // นับสถิติหมวดหมู่
            $cat = $item['category'] ? $item['category'] : 'ทั่วไป';
            if (!isset($stats['categories'][$cat])) {
                $stats['categories'][$cat] = 0;
            }
            $stats['categories'][$cat]++;
        }

        return $stats;
    }
}
?>