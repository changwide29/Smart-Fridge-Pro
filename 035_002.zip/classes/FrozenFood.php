<?php
// classes/FrozenFood.php

class FrozenFood extends FoodItem {
    private $temperatureRequired;

    public function __construct($name, $quantity, $unit, $temperatureRequired, $id = null) {
        // เรียกใช้ Constructor ของคลาสแม่
        parent::__construct($name, $quantity, $unit, $id);
        $this->temperatureRequired = $temperatureRequired;
    }

    public function getTemperatureRequired() {
        return $this->temperatureRequired;
    }
}
?>