<?php
// classes/FoodItem.php

class FoodItem {
    // กำหนด Access Modifier เป็น protected เพื่อให้คลาสลูกเรียกใช้ได้
    protected $id;
    protected $name;
    protected $quantity;
    protected $unit;

    // Constructor รับค่าเมื่อเริ่มสร้างออบเจกต์
    public function __construct($name, $quantity, $unit, $id = null) {
        $this->id = $id;
        $this->name = $name;
        $this->quantity = $quantity;
        $this->unit = $unit;
    }

    // Getters สำหรับดึงค่าไปใช้งาน
    public function getId() { return $this->id; }
    public function getName() { return $this->name; }
    public function getQuantity() { return $this->quantity; }
    public function getUnit() { return $this->unit; }

    // Method พื้นฐานสำหรับแสดงรายละเอียด
    public function getSummary() {
        return "{$this->name} จำนวน {$this->quantity} {$this->unit}";
    }
}
?>