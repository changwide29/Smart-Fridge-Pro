<?php
// classes/PerishableFood.php

class PerishableFood extends FoodItem {
    private $expiryDate;

    public function __construct($name, $quantity, $unit, $expiryDate, $id = null) {
        // เรียกใช้ Constructor ของคลาสแม่
        parent::__construct($name, $quantity, $unit, $id);
        $this->expiryDate = $expiryDate;
    }

    public function getExpiryDate() {
        return $this->expiryDate;
    }

    // Method สำหรับคำนวณจำนวนวันที่เหลือก่อนหมดอายุ
    public function getDaysUntilExpiry() {
        if (!$this->expiryDate) return null;
        
        $exp = new DateTime($this->expiryDate);
        $today = new DateTime();
        
        // รีเซ็ตเวลาเป็นเที่ยงคืนตรงเพื่อให้คำนวณวันแม่นยำ
        $exp->setTime(0, 0, 0);
        $today->setTime(0, 0, 0);
        
        return (int)$today->diff($exp)->format('%r%a');
    }
}
?>