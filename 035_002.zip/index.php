<?php
// index.php
require_once 'includes/db_connect.php';
require_once 'includes/autoloader.php';

$fridge = new SmartFridge($pdo);

// --- 1. จัดการการเพิ่ม หรือ แก้ไขข้อมูล ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $type = $_POST['type'];
    $category = $_POST['category'];
    $quantity = (float)$_POST['quantity'];
    $unit = trim($_POST['unit']);
    $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
    $temperature = !empty($_POST['temperature']) ? $_POST['temperature'] : null;

    try {
        if (isset($_POST['action_type']) && $_POST['action_type'] === 'edit') {
            // โหมดแก้ไข
            $id = (int)$_POST['item_id'];
            $fridge->updateFoodInDB($id, $name, $type, $category, $quantity, $unit, $expiry_date, $temperature);
        } else {
            // โหมดเพิ่มใหม่
            $fridge->addFoodToDB($name, $type, $category, $quantity, $unit, $expiry_date, $temperature);
        }
        header("Location: index.php");
        exit;
    } catch (PDOException $e) {
        $error_message = "เกิดข้อผิดพลาด: " . $e->getMessage();
    }
}

// --- 2. จัดการการลบข้อมูล ---
if (isset($_GET['delete_id'])) {
    try {
        $fridge->removeFood((int)$_GET['delete_id']);
        header("Location: index.php");
        exit;
    } catch (PDOException $e) {
        $error_message = "เกิดข้อผิดพลาดในการลบ: " . $e->getMessage();
    }
}

// --- 3. ดึงข้อมูลและสถิติมาแสดงผล ---
try {
    $foodItems = $fridge->getAllFoodItems();
    $stats = $fridge->getDashboardStats();
    
    // เตรียมข้อมูลสำหรับ Chart.js
    $chartLabels = json_encode(array_keys($stats['categories']));
    $chartData = json_encode(array_values($stats['categories']));
} catch (PDOException $e) {
    die("เกิดข้อผิดพลาดในการดึงข้อมูล: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Fridge Pro</title>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600&display=swap" rel="stylesheet">
    <!-- นำเข้า Chart.js สำหรับทำกราฟ -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary: #4361ee; --secondary: #3f37c9; --bg-color: #f4f7fe;
            --card-bg: #ffffff; --text-main: #2b3674; --text-muted: #a3aed1;
            --danger: #ef4444; --warning: #f59e0b; --success: #10b981;
        }
        body { font-family: 'Prompt', sans-serif; background-color: var(--bg-color); color: var(--text-main); margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        
        /* Header */
        .header-box { background: linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%); border-radius: 20px; padding: 30px; color: white; text-align: center; margin-bottom: 20px; box-shadow: 0 10px 20px rgba(67, 97, 238, 0.15); }
        .header-box h1 { margin: 0; font-size: 2rem; }
        
        /* Dashboard Stats */
        .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .stat-card { background: var(--card-bg); padding: 20px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); text-align: center; }
        .stat-card h3 { margin: 0; font-size: 2.5rem; color: var(--primary); }
        .stat-card p { margin: 5px 0 0; color: var(--text-muted); font-size: 0.9rem; }
        .stat-chart { background: var(--card-bg); padding: 20px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); display: flex; justify-content: center; align-items: center; height: 180px; }
        
        /* Main Card & Action Bar */
        .card { background: var(--card-bg); border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.03); overflow: hidden; }
        .action-bar { padding: 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f3f8; flex-wrap: wrap; gap: 15px; }
        .search-box { padding: 10px 15px; border: 1px solid #e2e8f0; border-radius: 10px; width: 250px; font-family: 'Prompt'; }
        
        /* Buttons */
        .btn { padding: 10px 20px; border-radius: 10px; font-family: inherit; font-weight: 500; cursor: pointer; border: none; transition: 0.2s; text-decoration: none; display: inline-block; }
        .btn-add { background: var(--primary); color: white; }
        .btn-add:hover { background: var(--secondary); }
        .btn-edit { background: #fef3c7; color: #d97706; padding: 6px 12px; font-size: 0.85rem; }
        .btn-remove { background: #fee2e2; color: var(--danger); padding: 6px 12px; font-size: 0.85rem; }
        
        /* Table */
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #f8f9fc; color: var(--text-muted); padding: 15px 20px; font-weight: 500; }
        td { padding: 15px 20px; border-bottom: 1px solid #f1f3f8; }
        tr:hover { background: #fdfdfe; }
        
        /* Badges */
        .badge { padding: 5px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: 500; }
        .tag-cat { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }
        .type-perishable { background: #fff0f0; color: #d63384; }
        .type-frozen { background: #e0f2fe; color: #0284c7; }
        .type-general { background: #f3f4f6; color: #4b5563; }
        
        /* Modal */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: none; justify-content: center; align-items: center; z-index: 1000; backdrop-filter: blur(2px); }
        .modal-box { background: white; padding: 30px; border-radius: 20px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 8px; font-family: inherit; box-sizing: border-box; }
        .row { display: flex; gap: 15px; } .col { flex: 1; }
    </style>
</head>
<body>

    <div class="container">
        <div class="header-box">
            <h1>🧊 Smart Fridge Pro</h1>
            <p>ระบบจัดการตู้เย็นอัจฉริยะ (Dashboard & Management)</p>
        </div>

        <!-- ================= Dashboard Section ================= -->
        <div class="dashboard-grid">
            <div class="stat-card">
                <h3><?= $stats['total'] ?></h3>
                <p>📦 รายการทั้งหมด</p>
            </div>
            <div class="stat-card">
                <h3 style="color: var(--success);"><?= $stats['fresh'] ?></h3>
                <p>✅ สดใหม่</p>
            </div>
            <div class="stat-card">
                <h3 style="color: var(--warning);"><?= $stats['expiring_soon'] ?></h3>
                <p>⚠️ ใกล้หมดอายุ (≤ 3 วัน)</p>
            </div>
            <div class="stat-card">
                <h3 style="color: var(--danger);"><?= $stats['expired'] ?></h3>
                <p>🚨 หมดอายุแล้ว</p>
            </div>
            <!-- ส่วนแสดงกราฟหมวดหมู่ -->
            <div class="stat-chart">
                <canvas id="categoryChart"></canvas>
            </div>
        </div>

        <!-- ================= Main Table Section ================= -->
        <div class="card">
            <div class="action-bar">
                <!-- ระบบค้นหา Real-time -->
                <input type="text" id="searchInput" class="search-box" placeholder="🔍 ค้นหาชื่ออาหาร หรือ หมวดหมู่..." onkeyup="filterTable()">
                <button class="btn btn-add" onclick="openModal('add')">+ เพิ่มอาหาร</button>
            </div>

            <div style="overflow-x: auto;">
                <table id="foodTable">
                    <thead>
                        <tr>
                            <th>ชื่ออาหาร</th>
                            <th>หมวดหมู่</th>
                            <th>ประเภท</th>
                            <th>ปริมาณ</th>
                            <th>สถานะ / วันหมดอายุ</th>
                            <th style="text-align: center;">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($foodItems) > 0): ?>
                            <?php foreach ($foodItems as $item): ?>
                                <!-- เก็บข้อมูลไว้ใน data-attributes เพื่อดึงไปใช้ตอนกดปุ่ม Edit -->
                                <tr class="food-row" 
                                    data-id="<?= $item['id'] ?>"
                                    data-name="<?= htmlspecialchars($item['name']) ?>"
                                    data-type="<?= $item['type'] ?>"
                                    data-category="<?= htmlspecialchars($item['category']) ?>"
                                    data-quantity="<?= $item['quantity'] ?>"
                                    data-unit="<?= htmlspecialchars($item['unit']) ?>"
                                    data-expiry="<?= $item['expiry_date'] ?>"
                                    data-temp="<?= $item['temperature_required'] ?>">
                                    
                                    <td class="search-target"><strong><?= htmlspecialchars($item['name']) ?></strong></td>
                                    <td class="search-target"><span class="badge tag-cat"><?= htmlspecialchars($item['category'] ? $item['category'] : 'ทั่วไป') ?></span></td>
                                    <td>
                                        <?php if($item['type'] == 'perishable'): ?>
                                            <span class="badge type-perishable">🥩 ของสด</span>
                                        <?php elseif($item['type'] == 'frozen'): ?>
                                            <span class="badge type-frozen">❄ แช่แข็ง</span>
                                        <?php else: ?>
                                            <span class="badge type-general">📦 ทั่วไป</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($item['quantity']) ?> <?= htmlspecialchars($item['unit']) ?></td>
                                    <td>
                                        <?php 
                                            if ($item['expiry_date']) {
                                                $expDate = new DateTime($item['expiry_date']);
                                                $today = new DateTime();
                                                $today->setTime(0,0,0); $expDate->setTime(0,0,0);
                                                $daysLeft = (int)$today->diff($expDate)->format('%r%a');
                                                
                                                if ($daysLeft < 0) echo "<span class='badge' style='background:#fee2e2; color:#ef4444;'>🚨 หมดอายุ</span>";
                                                elseif ($daysLeft <= 3) echo "<span class='badge' style='background:#fef3c7; color:#d97706;'>⚠️ เหลือ $daysLeft วัน</span>";
                                                else echo "<span class='badge' style='background:#d1fae5; color:#059669;'>✅ เหลือ $daysLeft วัน</span>";
                                            } else {
                                                echo '<span style="color:#a3aed1; font-size:0.9rem;">- ไม่ระบุ -</span>';
                                            }
                                        ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <!-- ปุ่มแก้ไข ส่ง this ไปเพื่อดึงข้อมูลจาก tr -->
                                        <button class="btn btn-edit" onclick="openModal('edit', this)">แก้ไข</button>
                                        <a href="index.php?delete_id=<?= $item['id'] ?>" class="btn btn-remove" onclick="return confirm('นำ <?= htmlspecialchars($item['name']) ?> ออกใช่หรือไม่?');">นำออก</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr id="emptyRow"><td colspan="6" style="text-align:center; padding: 40px; color: var(--text-muted);">ตู้เย็นว่างเปล่า เริ่มต้นเพิ่มรายการอาหารได้เลย</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ================= Modal Form (ใช้ร่วมกันทั้ง เพิ่ม และ แก้ไข) ================= -->
    <div class="modal-overlay" id="foodModal">
        <div class="modal-box">
            <h3 id="modalTitle">🛒 เพิ่มอาหาร</h3>
            <form method="POST" action="index.php">
                <!-- ซ่อนค่าเพื่อบอกว่าเป็น Add หรือ Edit -->
                <input type="hidden" name="action_type" id="actionType" value="add">
                <input type="hidden" name="item_id" id="itemId" value="">
                
                <div class="form-group">
                    <label>ชื่ออาหาร *</label>
                    <input type="text" name="name" id="inputName" class="form-control" required>
                </div>
                
                <div class="row">
                    <div class="form-group col">
                        <label>ประเภท *</label>
                        <select name="type" id="inputType" class="form-control" onchange="toggleFields()" required>
                            <option value="general">📦 ทั่วไป (ของแห้ง)</option>
                            <option value="perishable">🥩 ของสด</option>
                            <option value="frozen">❄ แช่แข็ง</option>
                        </select>
                    </div>
                    <div class="form-group col">
                        <label>หมวดหมู่</label>
                        <!-- ระบบหมวดหมู่ -->
                        <select name="category" id="inputCategory" class="form-control">
                            <option value="ทั่วไป">ทั่วไป</option>
                            <option value="เนื้อสัตว์">เนื้อสัตว์</option>
                            <option value="ผักผลไม้">ผักผลไม้</option>
                            <option value="เครื่องดื่ม">เครื่องดื่ม</option>
                            <option value="ขนม/ของว่าง">ขนม/ของว่าง</option>
                            <option value="เครื่องปรุง">เครื่องปรุง</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col">
                        <label>ปริมาณ *</label>
                        <input type="number" step="0.1" name="quantity" id="inputQuantity" class="form-control" required>
                    </div>
                    <div class="form-group col">
                        <label>หน่วยนับ *</label>
                        <input type="text" name="unit" id="inputUnit" class="form-control" required placeholder="ชิ้น, กก, ลิตร">
                    </div>
                </div>

                <div class="form-group">
                    <label>วันหมดอายุ</label>
                    <input type="date" name="expiry_date" id="inputExpiry" class="form-control">
                </div>

                <div class="form-group" id="tempField" style="display: none;">
                    <label>อุณหภูมิเก็บรักษา (°C)</label>
                    <input type="number" step="0.1" name="temperature" id="inputTemp" class="form-control">
                </div>

                <button type="submit" class="btn btn-add" style="width: 100%; margin-top:10px;">💾 บันทึกข้อมูล</button>
                <button type="button" class="btn" style="width: 100%; margin-top:10px; background:#f1f5f9;" onclick="closeModal()">ยกเลิก</button>
            </form>
        </div>
    </div>

    <!-- ================= JavaScript ================= -->
    <script>
        // 1. ฟังก์ชันเปิด Modal อัจฉริยะ (จัดการทั้ง Add และ Edit)
        function openModal(mode, btnElement = null) {
            document.getElementById('foodModal').style.display = 'flex';
            
            if (mode === 'edit' && btnElement) {
                // ดึงข้อมูลจากแถวตาราง (tr) ที่กดปุ่มแก้ไข
                const row = btnElement.closest('tr');
                document.getElementById('modalTitle').innerText = '✏️ แก้ไขข้อมูลอาหาร';
                document.getElementById('actionType').value = 'edit';
                document.getElementById('itemId').value = row.getAttribute('data-id');
                
                document.getElementById('inputName').value = row.getAttribute('data-name');
                document.getElementById('inputType').value = row.getAttribute('data-type');
                document.getElementById('inputCategory').value = row.getAttribute('data-category');
                document.getElementById('inputQuantity').value = row.getAttribute('data-quantity');
                document.getElementById('inputUnit').value = row.getAttribute('data-unit');
                document.getElementById('inputExpiry').value = row.getAttribute('data-expiry') || '';
                document.getElementById('inputTemp').value = row.getAttribute('data-temp') || '';
            } else {
                // โหมดเพิ่มใหม่ ล้างค่าทั้งหมด
                document.getElementById('modalTitle').innerText = '🛒 เพิ่มอาหาร';
                document.getElementById('actionType').value = 'add';
                document.getElementById('itemId').value = '';
                document.getElementById('inputName').value = '';
                document.getElementById('inputQuantity').value = '1';
                document.getElementById('inputUnit').value = '';
                document.getElementById('inputExpiry').value = '';
                document.getElementById('inputTemp').value = '';
            }
            toggleFields(); // ตรวจสอบการแสดงช่องอุณหภูมิ
        }

        function closeModal() {
            document.getElementById('foodModal').style.display = 'none';
        }

        function toggleFields() {
            var type = document.getElementById('inputType').value;
            document.getElementById('tempField').style.display = (type === 'frozen') ? 'block' : 'none';
        }

        // 2. ระบบค้นหาแบบ Real-time (Search & Filter)
        function filterTable() {
            const input = document.getElementById("searchInput").value.toLowerCase();
            const rows = document.querySelectorAll(".food-row");
            
            rows.forEach(row => {
                // ค้นหาจากชื่ออาหาร และ หมวดหมู่
                const textContent = row.innerText.toLowerCase();
                if (textContent.includes(input)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }

        // 3. แสดงกราฟโดนัทหมวดหมู่อาหาร (Chart.js)
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('categoryChart').getContext('2d');
            const dataLabels = <?= $chartLabels ?>;
            const dataValues = <?= $chartData ?>;

            if(dataValues.length > 0) {
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: dataLabels,
                        datasets: [{
                            data: dataValues,
                            backgroundColor: ['#4361ee', '#4cc9f0', '#f72585', '#7209b7', '#f59e0b', '#10b981'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'right', labels: { font: { family: 'Prompt' } } }
                        }
                    }
                });
            } else {
                // กรณีไม่มีข้อมูลให้ซ่อนกราฟ
                document.getElementById('categoryChart').style.display = 'none';
                ctx.font = "14px Prompt";
                ctx.fillText("ไม่มีข้อมูล", 50, 90);
            }
        });
    </script>
</body>
</html>