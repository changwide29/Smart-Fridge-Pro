<?php
// includes/db_connect.php

$host = 'localhost';
$dbname = 'u835268696_035002'; // ชื่อฐานข้อมูล
$username = 'u835268696_035002'; // ชื่อผู้ใช้งาน
$password = 'Zx035_002'; // <<< ใส่รหัสผ่าน Database ของคุณที่นี่

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    // สร้างการเชื่อมต่อ PDO
    $pdo = new PDO($dsn, $username, $password, $options);
    
} catch (PDOException $e) {
    // จัดการข้อผิดพลาดถ้าเชื่อมต่อไม่ได้
    die("การเชื่อมต่อฐานข้อมูลล้มเหลว: " . $e->getMessage());
}
?>