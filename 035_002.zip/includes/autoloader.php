<?php
// includes/autoloader.php

spl_autoload_register(function ($className) {
    // กำหนดเส้นทางไปยังโฟลเดอร์ classes
    $path = __DIR__ . '/../classes/';
    $extension = '.php';
    $fullPath = $path . $className . $extension;

    if (file_exists($fullPath)) {
        require_once $fullPath;
    } else {
        error_log("ไม่พบไฟล์ Class: " . $fullPath);
    }
});
?>